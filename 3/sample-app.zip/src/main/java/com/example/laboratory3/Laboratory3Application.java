package com.example.laboratory3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Laboratory3Application {

	public static void main(String[] args) {
		SpringApplication.run(Laboratory3Application.class, args);
	}

}
